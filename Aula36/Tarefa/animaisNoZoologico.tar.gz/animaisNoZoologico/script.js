let animais = [ 
  { nome: "Leão", especie: "Felino", peso: 190, idade: 8 }, 
  { nome: "Elefante", especie: "Mamífero", peso: 5400, idade: 
25 }, 
  { nome: "Girafa", especie: "Herbívoro", peso: 800, idade: 12 
}, 
  { nome: "Macaco", especie: "Primata", peso: 40, idade: 5 }, 
  { nome: "Tigre", especie: "Felino", peso: 220, idade: 10 } 
]; 

let processBtn = document.getElementById("processBtn");
let resetBtn = document.getElementById("resetBtn");
let outputEl = document.getElementById("output");

processBtn.addEventListener("click", () => {
    outputEl.textContent = "";

    let lista = animais.shift(",").map(item => item.trim());

    lista.push({ nome: "Coala", especie: "Primata", peso: 20, idade: 5 });
});

let altas = animais.filter(r => r.peso > 200);

